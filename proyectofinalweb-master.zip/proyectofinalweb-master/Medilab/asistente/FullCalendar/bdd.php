<?php
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=final_web;charset=utf8', 'root', 'mysql');
}
catch(Exception $e)
{
        die('Error : '.$e->getMessage());
}
