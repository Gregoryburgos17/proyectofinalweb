<?php 
 

include('../conexion/conexion.php');
include('../conexion/config.php');

$error='';

if($_POST){
    session_start();
    $user= $_POST['correo'];
    $pass= $_POST['clave'];
    $rol = $_POST['rol'];

    $pass= md5($pass);

    $sql= "select * from {$rol} where user = '{$user}' and pass= '{$pass}'";
    $execute= conexion::execute($sql);
    $cont= mysqli_num_rows($execute);

    $fila= $execute->fetch_row();
    
    if($cont != 0)
    {
        $_SESSION['tipo_usuario']= $fila[5];
        $_SESSION['nombre']= $fila[1].' '.$fila[2];
    }
    else
    {
        $error= "Datos erróneos - Usuario o contraseña incorrecto";
    }
    if(isset($_SESSION['tipo_usuario'])){
        header("Location: ../index.php");
    }
} 
?>


<!DOCTYPE html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
   
    <title>Sistema de Consultas</title>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
</head>
<body>
<div class="container">
      <div class="row mt-3">
          <div class="col mt-3 ">
             <h4 style="color:#1977cc; font-size:35px;" class="font-weight:700 text-center">Sistema de Consultas</h4><br>
                <form  method="post" action="">
                    <div class="form-group">
                        <label for="correo">Usuario</label>
                        <input type="email" class="form-control" name="correo" id="correo" placeholder="Ingrese su correo" required>
                    </div> 
                    <br>
                    <div class="form-group">
                        <label for="clave">Contraseña</label>
                        <input type="password" class="form-control" name="clave" id="clave" placeholder="Ingrese su contraseña" required>
                    </div>
                    <div class="form-group">
                        <label for="rol">Rol</label>
                        <select name="rol" class="form-control" id="rol" required>
                        <option value="admin" >Administrador</option>
                        <option value="doctor" >Doctor</option>
                        <option value="asistente">Asistente</option>
                       </select>
                    </div>
                      <br>
                    <center><button type="submit" class="btn" style="background:#1977cc;font-weight:600;color:white;width:250px;">Iniciar Sesion</button></center>         
                  </form>
                  <div style="color:red;">
                     <span><? echo $error; ?></span>
                  </div>
                  <br>
                    
                    <a href="recuperar_pass.php">Olvidé mi contraseña</a>
              
                
          </div>
      </div>
</div>
</body>
</html>
  