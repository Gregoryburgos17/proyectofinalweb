<a href="FullCalendar/index.php"><button style="float: right" type="button" class="btn btn-success" >consulta de eventos</button></a> 
<div>
   <table class="table">
      <thead>
        <tr>
          <th>foto</th>
          <th>Cédula</th>
        </tr>
      </thead>
      <tbody>
        <?php loadtable(); ?>

      </tbody>
   </table>
</div>