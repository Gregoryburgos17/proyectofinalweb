<a href="FullCalendar/index.php"><button style="float: right" type="button" class="btn btn-success" >consulta de eventos</button></a> 
<div>
   <table class="table">
      <thead>
        <tr>
          <th>foto</th>
          <th>Cédula</th>
        </tr>
      </thead>
      <tbody>
        <?php
        include('conex/conex.php');
        include('conex/conx.php');
        extract($_POST);
        $consulta= conexion::query_array("select * from user  WHERE cedula={$cedula}");
        foreach($consulta as $data){
          echo"
        <tr>
        <td>{$data['cedula']}</td>
        <td>{$data['fecha']}</td>
        </tr>
        ";

        }
        
        

        

        
        ?>

      </tbody>
   </table>
</div>