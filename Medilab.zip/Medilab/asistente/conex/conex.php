<?php
//GREGORY BURGOS 
define('BD_HOST','localhost');
define('BD_USER','root');
define('BD_PASS','');
define('BD_NAME','practica');


?>