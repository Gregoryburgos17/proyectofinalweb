<?php
include('conex/conex.php');
include('conex/conx.php');


if($_POST){
    extract($_POST);
   
    $insert= "INSERT INTO solicitude (cedula, nombre, Apellido) VALUES ('{$cedula}', '{$nombre}', '{$apellido}')";
    conexion:: ejercutar($insert);
   
}
   
?>


<form method="POST"  >
    <div class="form-group">
      <label for="cedula">Cedula</label>
      <input type="text" class="form-control" id="cedula" name="cedula" placeholder="Escriba su cédula" required>
      <small id="emailHelp" class="form-text text-muted">dame tu cedula</small>
    </div>
    <div class="form-group">
      <label for="nombre">Nombre</label>
      <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Escriba su nombre" required>
    </div>
    <div class="form-group">
      <label for="apellido">Apellido</label>
      <input type="text" class="form-control" id="apellido" name="apellido" placeholder="Escriba su apellido" required>
    </div>
    <div class="form-group">
      <label for="apellido">fecha de nacimiento</label>
      <input type="date" class="form-control" id="fecha" name="fecha" placeholder="Escriba su apellido" required>
    </div>
    <div class="form-group">
      <label for="apellido">Tipo de sangre</label>
      <input type="text" class="form-control" id="sangre" name="sangre" placeholder="Escriba su apellido" required>
    </div>
    
    <button type="submit" class="btn btn-primary" >Enviar</button>
   
</form>