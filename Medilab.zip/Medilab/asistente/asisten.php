<?php
include('conex/conex.php');
include('conex/conx.php');
if($_POST){
    extract($_POST);
    $id= conexion::query_array("select * from user where cedula={$cedula}");
    if($id[0]>0){
        echo"
        <script>
        window.location='data.php';
        </script>
        ";

    }
    else{
        echo"
        <script>
        window.location='registro.php';
        </script>
        
        
        ";
    }
       
}

?>
<form method="POST"  >
<h2>verificacion de usuario</h2>
    <div class="form-group">
      <label for="cedula">Cedula</label>
      <input type="text" class="form-control" id="cedula" name="cedula" placeholder="Escriba su cédula" required>
      <small id="emailHelp" class="form-text text-muted">dame tu cedula</small>
    </div>
    <button type="submit" class="btn btn-primary" >Enviar</button>
</form>