<?php 

session_start();

include('conexion/conexion.php');
include('conexion/config.php');
include('head.php');

?>

<h3 class="text-dark">Reportes del Sistema</h3>
<br>

<table class="table">
   <thead>
      <tr>
        <th class="text-info">Fecha</th>
        <th class="text-info">Actividad</th>
        <th class="text-info">Usuario Operario</th>
        <th class="text-info">Usuario Afectado</th>
      </tr>
   </thead>
   <tbody>
      <?php 
         
         $sql= "select * from reporte_sistema";
         $data= conexion::execute($sql);

         foreach($data as $dato){
             echo "
               <tr>
                  <td>{$dato['fecha']}</td>
                  <td>{$dato['actividad']}</td>
                  <td>{$dato['usuario_c']}</td>
                  <td>{$dato['usuario_afectado']}</td>
               </tr>
             ";
         }     
      
      ?>
   </tbody>
</table>

<?include('foot.php'); ?>